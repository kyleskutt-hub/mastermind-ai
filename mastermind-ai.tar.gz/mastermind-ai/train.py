"""
Mastermind AI Training Script
=============================
Train a neural network to play Mastermind.

Author: Kyle Skutt
License: Apache 2.0

Usage:
    python train.py --episodes 10000 --save-every 1000
"""

import argparse
import os
import time
from datetime import datetime
from tqdm import tqdm
import numpy as np
import torch

from mastermind.environment import MastermindEnv
from mastermind.agent import MastermindAgent, RandomAgent, MinimaxAgent


def train(
    num_episodes: int = 10000,
    save_every: int = 1000,
    eval_every: int = 500,
    save_dir: str = "checkpoints",
    hidden_sizes: list = [256, 256, 128],
    lr: float = 3e-4,
    gamma: float = 0.99
):
    """
    Train the Mastermind AI agent.
    
    Parameters
    ----------
    num_episodes : int
        Total number of training episodes
    save_every : int
        Save checkpoint every N episodes
    eval_every : int
        Run evaluation every N episodes
    save_dir : str
        Directory for saving checkpoints
    hidden_sizes : list
        Hidden layer sizes for neural network
    lr : float
        Learning rate
    gamma : float
        Discount factor
    """
    # Create save directory
    os.makedirs(save_dir, exist_ok=True)
    
    # Initialize environment and agent
    env = MastermindEnv()
    agent = MastermindAgent(
        state_size=env.state_size,
        action_size=env.action_space_size,
        hidden_sizes=hidden_sizes,
        lr=lr,
        gamma=gamma
    )
    
    print("=" * 60)
    print("MASTERMIND AI TRAINING")
    print("=" * 60)
    print(f"State size: {env.state_size}")
    print(f"Action space: {env.action_space_size}")
    print(f"Hidden layers: {hidden_sizes}")
    print(f"Learning rate: {lr}")
    print(f"Episodes: {num_episodes}")
    print("=" * 60)
    
    # Training loop
    start_time = time.time()
    total_losses = []
    
    pbar = tqdm(range(1, num_episodes + 1), desc="Training")
    
    for episode in pbar:
        # Reset environment
        state = env.reset()
        done = False
        episode_reward = 0
        
        # Play episode
        while not done:
            action = agent.select_action(state)
            state, reward, done, info = env.step(action)
            agent.store_reward(reward)
            episode_reward += reward
        
        # End episode and update
        agent.end_episode(env.won, len(env.guess_history))
        loss = agent.update()
        total_losses.append(loss)
        
        # Update progress bar
        stats = agent.get_stats()
        pbar.set_postfix({
            "win": f"{stats['win_rate']:.1%}",
            "len": f"{stats['avg_length']:.1f}",
            "rew": f"{stats['avg_reward']:.1f}"
        })
        
        # Save checkpoint
        if episode % save_every == 0:
            checkpoint_path = os.path.join(save_dir, f"checkpoint_ep{episode}.pt")
            agent.save(checkpoint_path)
        
        # Evaluation
        if episode % eval_every == 0:
            eval_results = evaluate(agent, env, num_games=100)
            print(f"\n[Eval @ {episode}] Win: {eval_results['win_rate']:.1%}, "
                  f"Avg guesses: {eval_results['avg_guesses']:.2f}")
    
    # Final save
    final_path = os.path.join(save_dir, "final_model.pt")
    agent.save(final_path)
    
    # Training summary
    elapsed = time.time() - start_time
    print("\n" + "=" * 60)
    print("TRAINING COMPLETE")
    print("=" * 60)
    print(f"Total time: {elapsed / 60:.1f} minutes")
    print(f"Final stats: {agent.get_stats()}")
    print(f"Model saved: {final_path}")
    
    return agent


def evaluate(agent, env, num_games: int = 100) -> dict:
    """
    Evaluate agent performance.
    
    Parameters
    ----------
    agent : Agent
        Agent to evaluate
    env : MastermindEnv
        Environment
    num_games : int
        Number of games to play
        
    Returns
    -------
    results : dict
        Evaluation metrics
    """
    wins = 0
    total_guesses = 0
    
    for _ in range(num_games):
        state = env.reset()
        done = False
        
        while not done:
            action = agent.select_action(state, deterministic=True)
            state, reward, done, info = env.step(action)
        
        if env.won:
            wins += 1
        total_guesses += len(env.guess_history)
    
    return {
        "win_rate": wins / num_games,
        "avg_guesses": total_guesses / num_games,
        "games_played": num_games
    }


def benchmark(num_games: int = 100):
    """
    Benchmark different agents.
    
    Compares:
    - Random agent (baseline)
    - Trained neural network
    - Minimax (optimal)
    """
    env = MastermindEnv()
    
    agents = {
        "Random": RandomAgent(env.action_space_size),
        "Minimax (Optimal)": MinimaxAgent()
    }
    
    # Try to load trained model
    if os.path.exists("checkpoints/final_model.pt"):
        trained_agent = MastermindAgent(
            state_size=env.state_size,
            action_size=env.action_space_size
        )
        trained_agent.load("checkpoints/final_model.pt")
        agents["Neural Net (Trained)"] = trained_agent
    
    print("=" * 60)
    print("BENCHMARK RESULTS")
    print("=" * 60)
    print(f"Games per agent: {num_games}\n")
    
    for name, agent in agents.items():
        results = evaluate(agent, env, num_games)
        print(f"{name:25} | Win: {results['win_rate']:6.1%} | "
              f"Avg guesses: {results['avg_guesses']:.2f}")
    
    print("=" * 60)


def play_interactive():
    """Play against the AI or watch it play."""
    env = MastermindEnv()
    
    # Try to load trained model
    if os.path.exists("checkpoints/final_model.pt"):
        agent = MastermindAgent(
            state_size=env.state_size,
            action_size=env.action_space_size
        )
        agent.load("checkpoints/final_model.pt")
        print("Loaded trained model!")
    else:
        print("No trained model found. Using random agent.")
        agent = RandomAgent(env.action_space_size)
    
    print("\nWatching AI play Mastermind...\n")
    
    state = env.reset()
    done = False
    
    while not done:
        action = agent.select_action(state, deterministic=True)
        state, reward, done, info = env.step(action)
        print(env.render())
        print()
        time.sleep(0.5)
    
    if env.won:
        print(f"🎉 AI won in {len(env.guess_history)} guesses!")
    else:
        print("AI failed to crack the code.")


def main():
    parser = argparse.ArgumentParser(description="Train Mastermind AI")
    parser.add_argument("--episodes", type=int, default=10000,
                        help="Number of training episodes")
    parser.add_argument("--save-every", type=int, default=1000,
                        help="Save checkpoint every N episodes")
    parser.add_argument("--eval-every", type=int, default=500,
                        help="Evaluate every N episodes")
    parser.add_argument("--lr", type=float, default=3e-4,
                        help="Learning rate")
    parser.add_argument("--benchmark", action="store_true",
                        help="Run benchmark instead of training")
    parser.add_argument("--play", action="store_true",
                        help="Watch AI play")
    
    args = parser.parse_args()
    
    if args.benchmark:
        benchmark()
    elif args.play:
        play_interactive()
    else:
        train(
            num_episodes=args.episodes,
            save_every=args.save_every,
            eval_every=args.eval_every,
            lr=args.lr
        )


if __name__ == "__main__":
    main()
