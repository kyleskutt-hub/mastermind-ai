"""
Mastermind Game Environment
===========================
A reinforcement learning environment for the classic code-breaking game.

Author: Kyle Skutt
License: Apache 2.0
"""

import numpy as np
from typing import Tuple, List, Optional
from dataclasses import dataclass
from enum import IntEnum


class Color(IntEnum):
    """Six colors available in standard Mastermind."""
    RED = 0
    BLUE = 1
    GREEN = 2
    YELLOW = 3
    WHITE = 4
    BLACK = 5


@dataclass
class Feedback:
    """Feedback from a guess."""
    black_pegs: int  # Correct color AND position
    white_pegs: int  # Correct color, wrong position
    
    def is_win(self, code_length: int = 4) -> bool:
        return self.black_pegs == code_length
    
    def to_tuple(self) -> Tuple[int, int]:
        return (self.black_pegs, self.white_pegs)
    
    def __repr__(self) -> str:
        return f"⚫×{self.black_pegs} ⚪×{self.white_pegs}"


class MastermindEnv:
    """
    Mastermind Environment for Reinforcement Learning.
    
    State space: Previous guesses and their feedback
    Action space: All possible color combinations (6^4 = 1296)
    Reward: Based on feedback quality and winning
    
    Parameters
    ----------
    code_length : int
        Number of positions in the code (default: 4)
    num_colors : int
        Number of available colors (default: 6)
    max_guesses : int
        Maximum attempts before game over (default: 10)
    """
    
    def __init__(
        self,
        code_length: int = 4,
        num_colors: int = 6,
        max_guesses: int = 10
    ):
        self.code_length = code_length
        self.num_colors = num_colors
        self.max_guesses = max_guesses
        
        # Action space size: num_colors ^ code_length
        self.action_space_size = num_colors ** code_length
        
        # State tracking
        self.secret_code: Optional[np.ndarray] = None
        self.guess_history: List[np.ndarray] = []
        self.feedback_history: List[Feedback] = []
        self.done: bool = False
        self.won: bool = False
        
    def reset(self, secret_code: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Reset the environment for a new game.
        
        Parameters
        ----------
        secret_code : optional
            Specific code to use (for testing). If None, generates random.
            
        Returns
        -------
        state : np.ndarray
            Initial state representation
        """
        if secret_code is not None:
            self.secret_code = np.array(secret_code)
        else:
            self.secret_code = np.random.randint(0, self.num_colors, self.code_length)
        
        self.guess_history = []
        self.feedback_history = []
        self.done = False
        self.won = False
        
        return self._get_state()
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, dict]:
        """
        Take a step in the environment.
        
        Parameters
        ----------
        action : int
            Index of the guess (0 to action_space_size-1)
            
        Returns
        -------
        state : np.ndarray
            New state after the guess
        reward : float
            Reward for this step
        done : bool
            Whether the game is over
        info : dict
            Additional information
        """
        if self.done:
            raise ValueError("Game is over. Call reset() to start a new game.")
        
        # Convert action index to guess
        guess = self._action_to_guess(action)
        
        # Get feedback
        feedback = self._evaluate_guess(guess)
        
        # Store history
        self.guess_history.append(guess)
        self.feedback_history.append(feedback)
        
        # Check win condition
        if feedback.is_win(self.code_length):
            self.done = True
            self.won = True
            reward = self._calculate_reward(feedback, won=True)
        elif len(self.guess_history) >= self.max_guesses:
            self.done = True
            self.won = False
            reward = self._calculate_reward(feedback, won=False, out_of_guesses=True)
        else:
            reward = self._calculate_reward(feedback)
        
        state = self._get_state()
        info = {
            "guess": guess,
            "feedback": feedback,
            "num_guesses": len(self.guess_history),
            "won": self.won
        }
        
        return state, reward, self.done, info
    
    def _evaluate_guess(self, guess: np.ndarray) -> Feedback:
        """
        Evaluate a guess against the secret code.
        
        Uses the standard Mastermind scoring:
        - Black peg: correct color in correct position
        - White peg: correct color in wrong position
        """
        black_pegs = 0
        white_pegs = 0
        
        secret_remaining = list(self.secret_code)
        guess_remaining = list(guess)
        
        # First pass: find exact matches (black pegs)
        for i in range(self.code_length):
            if guess[i] == self.secret_code[i]:
                black_pegs += 1
                secret_remaining[i] = -1  # Mark as used
                guess_remaining[i] = -2   # Mark as used (different value)
        
        # Second pass: find color matches (white pegs)
        for i in range(self.code_length):
            if guess_remaining[i] >= 0:  # Not already matched
                for j in range(self.code_length):
                    if secret_remaining[j] >= 0 and guess_remaining[i] == secret_remaining[j]:
                        white_pegs += 1
                        secret_remaining[j] = -1  # Mark as used
                        break
        
        return Feedback(black_pegs, white_pegs)
    
    def _action_to_guess(self, action: int) -> np.ndarray:
        """Convert action index to guess array."""
        guess = np.zeros(self.code_length, dtype=np.int32)
        for i in range(self.code_length - 1, -1, -1):
            guess[i] = action % self.num_colors
            action //= self.num_colors
        return guess
    
    def _guess_to_action(self, guess: np.ndarray) -> int:
        """Convert guess array to action index."""
        action = 0
        for i in range(self.code_length):
            action = action * self.num_colors + guess[i]
        return action
    
    def _get_state(self) -> np.ndarray:
        """
        Get current state representation.
        
        State shape: (max_guesses, code_length + 2)
        Each row: [guess colors..., black_pegs, white_pegs]
        Unfilled rows are zeros.
        """
        state = np.zeros((self.max_guesses, self.code_length + 2), dtype=np.float32)
        
        for i, (guess, feedback) in enumerate(zip(self.guess_history, self.feedback_history)):
            # Normalize colors to [0, 1]
            state[i, :self.code_length] = guess / (self.num_colors - 1)
            # Normalize feedback to [0, 1]
            state[i, self.code_length] = feedback.black_pegs / self.code_length
            state[i, self.code_length + 1] = feedback.white_pegs / self.code_length
        
        return state
    
    def _calculate_reward(
        self,
        feedback: Feedback,
        won: bool = False,
        out_of_guesses: bool = False
    ) -> float:
        """
        Calculate reward for a guess.
        
        Reward structure:
        - Win: +10 bonus, scaled by how few guesses used
        - Each black peg: +1.0
        - Each white peg: +0.5
        - Out of guesses without winning: -5
        """
        reward = 0.0
        
        # Feedback reward
        reward += feedback.black_pegs * 1.0
        reward += feedback.white_pegs * 0.5
        
        # Win bonus (bigger if fewer guesses)
        if won:
            guesses_used = len(self.guess_history)
            efficiency_bonus = (self.max_guesses - guesses_used + 1) / self.max_guesses
            reward += 10.0 * efficiency_bonus
        
        # Penalty for running out of guesses
        if out_of_guesses and not won:
            reward -= 5.0
        
        return reward
    
    def render(self) -> str:
        """Return a string representation of the game state."""
        lines = ["=" * 40]
        lines.append("MASTERMIND")
        lines.append("=" * 40)
        
        color_symbols = ["🔴", "🔵", "🟢", "🟡", "⚪", "⚫"]
        
        for i, (guess, feedback) in enumerate(zip(self.guess_history, self.feedback_history)):
            guess_str = " ".join(color_symbols[c] for c in guess)
            lines.append(f"Guess {i+1}: {guess_str}  →  {feedback}")
        
        if self.done:
            if self.won:
                lines.append(f"\n🎉 WON in {len(self.guess_history)} guesses!")
            else:
                secret_str = " ".join(color_symbols[c] for c in self.secret_code)
                lines.append(f"\n❌ LOST. Secret was: {secret_str}")
        else:
            remaining = self.max_guesses - len(self.guess_history)
            lines.append(f"\n{remaining} guesses remaining")
        
        lines.append("=" * 40)
        return "\n".join(lines)
    
    def get_valid_actions(self) -> np.ndarray:
        """Return array of all valid action indices."""
        return np.arange(self.action_space_size)
    
    @property
    def state_size(self) -> int:
        """Size of flattened state vector."""
        return self.max_guesses * (self.code_length + 2)


# Convenience function for testing
def play_random_game():
    """Play a game with random guesses."""
    env = MastermindEnv()
    state = env.reset()
    
    while not env.done:
        action = np.random.randint(env.action_space_size)
        state, reward, done, info = env.step(action)
        print(env.render())
    
    return env.won, len(env.guess_history)


if __name__ == "__main__":
    # Demo
    print("Playing a random game of Mastermind...\n")
    won, guesses = play_random_game()
