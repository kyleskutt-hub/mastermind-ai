"""
Mastermind AI
=============
A reinforcement learning environment and PyTorch agent for the classic
code-breaking game Mastermind.

Author: Kyle Skutt
License: Apache 2.0
"""

from mastermind.environment import MastermindEnv, Feedback, Color
from mastermind.agent import MastermindAgent, RandomAgent, MinimaxAgent

__version__ = "0.1.0"
__author__ = "Kyle Skutt"
__license__ = "Apache-2.0"

__all__ = [
    "MastermindEnv",
    "Feedback", 
    "Color",
    "MastermindAgent",
    "RandomAgent",
    "MinimaxAgent"
]
