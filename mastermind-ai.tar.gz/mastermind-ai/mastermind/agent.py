"""
Mastermind AI Agent (PyTorch)
=============================
Neural network agent that learns to play Mastermind using policy gradient.

Author: Kyle Skutt
License: Apache 2.0
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Categorical
import numpy as np
from typing import List, Tuple, Optional
from collections import deque
import random


class MastermindNetwork(nn.Module):
    """
    Neural network for Mastermind policy.
    
    Architecture:
    - Input: Flattened game state (guess history + feedback)
    - Hidden layers with ReLU activation
    - Output: Action probabilities over all possible guesses
    """
    
    def __init__(
        self,
        state_size: int,
        action_size: int,
        hidden_sizes: List[int] = [256, 256, 128]
    ):
        super().__init__()
        
        self.state_size = state_size
        self.action_size = action_size
        
        # Build network layers
        layers = []
        prev_size = state_size
        
        for hidden_size in hidden_sizes:
            layers.append(nn.Linear(prev_size, hidden_size))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.1))
            prev_size = hidden_size
        
        self.feature_layers = nn.Sequential(*layers)
        
        # Policy head (action probabilities)
        self.policy_head = nn.Linear(prev_size, action_size)
        
        # Value head (state value estimation for actor-critic)
        self.value_head = nn.Linear(prev_size, 1)
        
    def forward(self, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass.
        
        Returns
        -------
        action_probs : torch.Tensor
            Probability distribution over actions
        state_value : torch.Tensor
            Estimated value of the state
        """
        features = self.feature_layers(state)
        
        # Policy: softmax over actions
        action_logits = self.policy_head(features)
        action_probs = F.softmax(action_logits, dim=-1)
        
        # Value
        state_value = self.value_head(features)
        
        return action_probs, state_value
    
    def get_action(
        self,
        state: torch.Tensor,
        deterministic: bool = False
    ) -> Tuple[int, torch.Tensor]:
        """
        Select an action given a state.
        
        Parameters
        ----------
        state : torch.Tensor
            Current game state
        deterministic : bool
            If True, select best action. If False, sample from distribution.
            
        Returns
        -------
        action : int
            Selected action index
        log_prob : torch.Tensor
            Log probability of selected action (for training)
        """
        action_probs, _ = self.forward(state)
        
        if deterministic:
            action = torch.argmax(action_probs, dim=-1).item()
            log_prob = torch.log(action_probs[0, action])
        else:
            dist = Categorical(action_probs)
            action_tensor = dist.sample()
            action = action_tensor.item()
            log_prob = dist.log_prob(action_tensor)
        
        return action, log_prob


class MastermindAgent:
    """
    Reinforcement Learning agent for Mastermind.
    
    Uses Actor-Critic with PPO-style updates.
    """
    
    def __init__(
        self,
        state_size: int,
        action_size: int,
        lr: float = 3e-4,
        gamma: float = 0.99,
        hidden_sizes: List[int] = [256, 256, 128],
        device: str = "auto"
    ):
        # Set device
        if device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)
        
        print(f"Using device: {self.device}")
        
        # Network
        self.network = MastermindNetwork(
            state_size=state_size,
            action_size=action_size,
            hidden_sizes=hidden_sizes
        ).to(self.device)
        
        # Optimizer
        self.optimizer = optim.Adam(self.network.parameters(), lr=lr)
        
        # Hyperparameters
        self.gamma = gamma
        self.state_size = state_size
        self.action_size = action_size
        
        # Episode memory
        self.states = []
        self.actions = []
        self.rewards = []
        self.log_probs = []
        self.values = []
        
        # Training stats
        self.episode_rewards = deque(maxlen=100)
        self.episode_lengths = deque(maxlen=100)
        self.wins = deque(maxlen=100)
        
    def select_action(
        self,
        state: np.ndarray,
        deterministic: bool = False
    ) -> int:
        """Select action for given state."""
        state_tensor = torch.FloatTensor(state.flatten()).unsqueeze(0).to(self.device)
        
        with torch.no_grad() if deterministic else torch.enable_grad():
            action_probs, value = self.network(state_tensor)
            
            if deterministic:
                action = torch.argmax(action_probs, dim=-1).item()
                log_prob = None
            else:
                dist = Categorical(action_probs)
                action_tensor = dist.sample()
                action = action_tensor.item()
                log_prob = dist.log_prob(action_tensor)
                
                # Store for training
                self.states.append(state_tensor)
                self.actions.append(action)
                self.log_probs.append(log_prob)
                self.values.append(value)
        
        return action
    
    def store_reward(self, reward: float):
        """Store reward for current step."""
        self.rewards.append(reward)
    
    def end_episode(self, won: bool, num_guesses: int):
        """Record episode statistics."""
        total_reward = sum(self.rewards)
        self.episode_rewards.append(total_reward)
        self.episode_lengths.append(num_guesses)
        self.wins.append(1 if won else 0)
    
    def update(self) -> float:
        """
        Update network using collected experience.
        
        Returns
        -------
        loss : float
            Total loss for this update
        """
        if len(self.rewards) == 0:
            return 0.0
        
        # Calculate returns (discounted cumulative rewards)
        returns = []
        R = 0
        for r in reversed(self.rewards):
            R = r + self.gamma * R
            returns.insert(0, R)
        
        returns = torch.FloatTensor(returns).to(self.device)
        
        # Normalize returns
        if len(returns) > 1:
            returns = (returns - returns.mean()) / (returns.std() + 1e-8)
        
        # Stack tensors
        log_probs = torch.stack(self.log_probs)
        values = torch.cat(self.values).squeeze()
        
        # Calculate advantages
        advantages = returns - values.detach()
        
        # Policy loss (negative because we want to maximize)
        policy_loss = -(log_probs * advantages).mean()
        
        # Value loss
        value_loss = F.mse_loss(values, returns)
        
        # Total loss
        loss = policy_loss + 0.5 * value_loss
        
        # Backprop
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.network.parameters(), 1.0)
        self.optimizer.step()
        
        # Clear episode memory
        self.states = []
        self.actions = []
        self.rewards = []
        self.log_probs = []
        self.values = []
        
        return loss.item()
    
    def get_stats(self) -> dict:
        """Get training statistics."""
        return {
            "avg_reward": np.mean(self.episode_rewards) if self.episode_rewards else 0,
            "avg_length": np.mean(self.episode_lengths) if self.episode_lengths else 0,
            "win_rate": np.mean(self.wins) if self.wins else 0,
            "episodes": len(self.episode_rewards)
        }
    
    def save(self, path: str):
        """Save model checkpoint."""
        torch.save({
            "network_state_dict": self.network.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "stats": self.get_stats()
        }, path)
        print(f"Model saved to {path}")
    
    def load(self, path: str):
        """Load model checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)
        self.network.load_state_dict(checkpoint["network_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        print(f"Model loaded from {path}")
        return checkpoint.get("stats", {})


class RandomAgent:
    """Baseline agent that guesses randomly."""
    
    def __init__(self, action_size: int):
        self.action_size = action_size
    
    def select_action(self, state: np.ndarray, deterministic: bool = False) -> int:
        return np.random.randint(self.action_size)
    
    def store_reward(self, reward: float):
        pass
    
    def end_episode(self, won: bool, num_guesses: int):
        pass
    
    def update(self) -> float:
        return 0.0


class MinimaxAgent:
    """
    Agent using minimax strategy (Knuth's algorithm).
    
    This is the optimal strategy - uses at most 5 guesses.
    Used as a benchmark.
    """
    
    def __init__(self, code_length: int = 4, num_colors: int = 6):
        self.code_length = code_length
        self.num_colors = num_colors
        self.action_size = num_colors ** code_length
        
        # Generate all possible codes
        self.all_codes = self._generate_all_codes()
        self.possible_codes = None
        self.first_guess = self._encode([0, 0, 1, 1])  # Classic first guess
        
    def _generate_all_codes(self) -> List[Tuple[int, ...]]:
        """Generate all possible codes."""
        codes = []
        for i in range(self.action_size):
            code = []
            val = i
            for _ in range(self.code_length):
                code.append(val % self.num_colors)
                val //= self.num_colors
            codes.append(tuple(reversed(code)))
        return codes
    
    def _encode(self, code: List[int]) -> int:
        """Convert code to action index."""
        action = 0
        for c in code:
            action = action * self.num_colors + c
        return action
    
    def _evaluate(self, guess: Tuple[int, ...], secret: Tuple[int, ...]) -> Tuple[int, int]:
        """Evaluate guess against a potential secret."""
        black = sum(g == s for g, s in zip(guess, secret))
        
        guess_counts = [0] * self.num_colors
        secret_counts = [0] * self.num_colors
        for g, s in zip(guess, secret):
            if g != s:
                guess_counts[g] += 1
                secret_counts[s] += 1
        
        white = sum(min(guess_counts[i], secret_counts[i]) for i in range(self.num_colors))
        return (black, white)
    
    def select_action(self, state: np.ndarray, deterministic: bool = True) -> int:
        """Select action using minimax."""
        # Count how many guesses have been made
        num_guesses = int(np.sum(state[:, :self.code_length].any(axis=1)))
        
        if num_guesses == 0:
            self.possible_codes = list(self.all_codes)
            return self.first_guess
        
        # Get last guess and feedback from state
        last_row = state[num_guesses - 1]
        last_guess = tuple(int(c * (self.num_colors - 1) + 0.5) for c in last_row[:self.code_length])
        black_pegs = int(last_row[self.code_length] * self.code_length + 0.5)
        white_pegs = int(last_row[self.code_length + 1] * self.code_length + 0.5)
        feedback = (black_pegs, white_pegs)
        
        # Filter possible codes
        self.possible_codes = [
            code for code in self.possible_codes
            if self._evaluate(last_guess, code) == feedback
        ]
        
        if len(self.possible_codes) == 1:
            return self._encode(list(self.possible_codes[0]))
        
        # Just pick first remaining (simplified from full minimax)
        return self._encode(list(self.possible_codes[0]))
    
    def store_reward(self, reward: float):
        pass
    
    def end_episode(self, won: bool, num_guesses: int):
        self.possible_codes = None
    
    def update(self) -> float:
        return 0.0


if __name__ == "__main__":
    # Quick test
    from environment import MastermindEnv
    
    env = MastermindEnv()
    agent = MastermindAgent(
        state_size=env.state_size,
        action_size=env.action_space_size
    )
    
    # Test one episode
    state = env.reset()
    done = False
    
    while not done:
        action = agent.select_action(state)
        state, reward, done, info = env.step(action)
        agent.store_reward(reward)
        print(env.render())
    
    agent.end_episode(env.won, len(env.guess_history))
    loss = agent.update()
    print(f"\nLoss: {loss:.4f}")
    print(f"Stats: {agent.get_stats()}")
